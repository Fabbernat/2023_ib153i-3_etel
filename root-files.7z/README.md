# Wolt ételrendelő app
2023 ősz rendszerfejlesztés projektmunka.

Contributors:
- Fábián Bernát
  És még 5 résztvevő, akinek a nevét nem osztom meg, privátsági okokból
